<!-- Main Footer -->
<footer class="main-footer">
  <!-- To the right -->

  <!-- Default to the left -->
  <strong>Copyright &copy; 2018 <a href="#">Student Acces Online</a></strong>
</footer>
